import {Component, inject, Signal} from '@angular/core';
import { FavoritesService } from '../services/favorites.service';
import { MovieItemComponent } from '../movie-item/movie-item.component';
import { HighlightDirective } from '../highlight.directive';
import { RouterOutlet } from '@angular/router';
import { Movie } from '../model/movie.model';
import { MoviesService } from '../services/movies.service';



@Component({
  selector: 'app-home',
  standalone: true,
    imports: [
      MovieItemComponent, HighlightDirective
    ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  protected movies: Signal<Movie[]> = inject(MoviesService).getMovies();
  protected favoritesService = inject(FavoritesService);
}
