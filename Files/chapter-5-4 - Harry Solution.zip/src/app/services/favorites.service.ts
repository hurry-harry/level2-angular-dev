import {computed, Injectable, signal, Signal} from '@angular/core';
import { Movie } from '../model/movie.model';

@Injectable({
  providedIn: 'root'
})
export class FavoritesService {
  private favouriteMovies: Signal<Movie[]> = signal<Movie[]>([]);

  toggleFavouriteMovie(movie: Movie): void {
    const index = this.favouriteMovies().indexOf(movie);

    if (index != -1)
      this.favouriteMovies().splice(index, 1);
    else
      this.favouriteMovies().push(movie);

    console.log('Toggled Faves, ', this.favouriteMovies());
  }

  isFavouriteMovie(movie: Movie): boolean {
    return this.favouriteMovies().includes(movie);
  }
}
