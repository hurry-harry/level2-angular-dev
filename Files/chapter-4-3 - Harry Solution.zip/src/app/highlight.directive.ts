import { Directive, ElementRef, HostBinding, HostListener, inject, input } from '@angular/core';

@Directive({
  selector: '[appHighlight]',
  standalone: true
})
export class HighlightDirective {
  
  @HostBinding('class.highlight')
  highlight: boolean = false;
  
  @HostListener('mouseenter')
  onEnter() {
    this.highlight = true;
  }

  @HostListener('mouseleave')
  onLeave() {
    this.highlight = false;
  }

}
