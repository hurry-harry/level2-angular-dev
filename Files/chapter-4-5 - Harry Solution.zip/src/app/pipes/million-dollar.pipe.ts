import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'millionDollar',
  standalone: true
})
export class MillionDollarPipe implements PipeTransform {
  transform(budget: string): string {
    if (budget.includes('-')) {
      let budgetArray: string[] = budget.split('-');

      return `$${budgetArray[0]} to $${budgetArray[1]} million`;
    } else 
      return `$${budget} million`
  }
}
