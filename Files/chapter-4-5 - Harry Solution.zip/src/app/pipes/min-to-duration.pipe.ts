import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'minToDuration',
  standalone: true
})
export class MinToDurationPipe implements PipeTransform {
  transform(duration: string): string {
    const durationNumber = parseInt(duration);
    if (durationNumber > 60) {
      let hours: number = Math.floor(durationNumber / 60);
      let mins: number = durationNumber % 60;

      return `${hours}h ${mins}min`;
    } else 
      return `${durationNumber}min`;
  }
}
