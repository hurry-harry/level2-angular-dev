import { Component, input, model } from '@angular/core';
import { Movie } from '../model/movie.model';


@Component({
  selector: 'app-movie-item',
  template: `
    <div class="movie-item">
      <div>
        <h4>{{input().title}}</h4>
        <small class="subtitle">
          <span>Release date: {{input().release_date}}</span>
          <span>Budget: $ {{input().budget}} million</span>
          <span>Duration: {{input().duration}} min</span>
        </small>
      </div>
      <button>Details</button>
    </div>
  `,
  standalone: true,
  styleUrls: [ 'movie-item.component.scss' ]
})
export class MovieItemComponent {
  input = model.required<Movie>();
}
